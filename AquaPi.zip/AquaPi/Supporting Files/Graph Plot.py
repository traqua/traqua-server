##Import Packages + Modules
import numpy as np
import os
import matplotlib.pyplot as plt

##Time and Flow Arrays
flowrate = []
time = []

def GenGraph(filename):
    ##Read CSV File (First line is Flow Rate, Second line is Time)
    flowrate = np.loadtxt(os.path.abspath("$Rooms/" + filename),delimiter=',', usecols=(0), skiprows=1)
    time = np.loadtxt(os.path.abspath("$Rooms/" + filename),delimiter=',', usecols=(1), skiprows=1)
    print(flowrate)
    print(time)

    ##Initialisation and plotting of graph/data
    plt.interactive(False)
    plt.figure()

    ##Plot point
    plt.plot([time], [flowrate], marker='o', markersize=5, color="red")
    plt.plot(time, flowrate,color = "blue")

    ##Label graph
    plt.xlabel("Time (Hrs)")
    plt.ylabel("Flow Rate (Litres per Second)")
    plt.savefig("$Rooms/Output/" + filename + ".png")

##Get Files in Folder
for root, dirs, files in os.walk("$Rooms"):
    for filename in files:
        GenGraph(filename)

######IMPORTANT READ ~ THERE WILL BE A COMPILATION ERROR AS THE OUTPUT FOLDER IS RECOGNISED AS AN EXTRA FILE, AND SO CANNOT BE FORMATTED AS A GRAPH, THE PROGRAM WORKS OTHERWISE.