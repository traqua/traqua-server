function loadXMLDoc() {
  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      myFunction(this);
    }
  }
  xmlhttp.open("GET", "http://localhost:80/AP/$Data/monthlydata.xml", true);
  xmlhttp.send();
}

function myFunction(xml) {
  var x, i, xmlDoc, txt;
  xmlDoc = xml.responseXML;
  txt = "<table style='width:50%; border:0.5px solid black'> <tr style='width:50%; border:1px solid black'></tr>"+
    "<th style='width:50%; border:0.5px solid black'>Appliance</th>"+
    "<th style='width:50%; border:0.5px solid black'>Room</th>"+
   "<th style='width:50%; border:0.5px solid black'>Average Rate</th>"+
   "<th style='width:50%; border:0.5px solid black'>Min Rate</th>"+
   "<th style='width:50%; border:0.5px solid black'>Max Rate</th>"+
   "<th style='width:50%; border:0.5px solid black'>Total</th>"+
  "</tr><br>";
  x = xmlDoc.getElementsByTagName("appname");
  y = xmlDoc.getElementsByTagName("room");
  z = xmlDoc.getElementsByTagName("avgrate");
  a = xmlDoc.getElementsByTagName("minrate");
  b = xmlDoc.getElementsByTagName("maxrate");
  c = xmlDoc.getElementsByTagName("total");
  for (i = 0; i< x.length; i++) {
	txt += "<tr style='width:50%; border:0.5px solid black'>"  
    txt += "<td style='width:50%; border:0.5px solid black'>" + x[i].childNodes[0].nodeValue + "</td>";
    txt += "<td style='width:50%; border:0.5px solid black'>" + y[i].childNodes[0].nodeValue + "</td>";
    txt += "<td style='width:50%; border:0.5px solid black'>" + z[i].childNodes[0].nodeValue + "</td>";
    txt += "<td style='width:50%; border:0.5px solid black'>" + a[i].childNodes[0].nodeValue + "</td>";
    txt += "<td style='width:50%; border:0.5px solid black'>" + b[i].childNodes[0].nodeValue + "</td>";
    txt += "<td style='width:50%; border:0.5px solid black'>" + c[i].childNodes[0].nodeValue + "</td>";
    txt += "</tr>";
  }
	txt += "</table>";
  document.getElementById("room").innerHTML = txt;
}
